Initial Setup
=============

.. image:: https://copr.fedorainfracloud.org/coprs/g/rhinstaller/Anaconda/package/initial-setup/status_image/last_build.png
    :alt: Build status
    :target: https://copr.fedorainfracloud.org/coprs/g/rhinstaller/Anaconda/package/initial-setup/

.. image:: https://translate.fedoraproject.org/widgets/initial-setup/-/master/svg-badge.svg
    :alt: Translation status
    :target: https://translate.fedoraproject.org/engage/initial-setup/?utm_source=widget

Initial Setup is an application that can run during the first start
of a newly installed computer and makes it possible to configure the
computer according to the needs of the user.

As most of the configuration options are already present during the
OS installation in Anaconda, Initial Setup mainly hosts options that
need to be presented during the first start, such as displaying the
EULA on RHEL. Initial Setup is also often used to create a user account,
as many systems are often automatically installed with kickstart
and the user is only expected to create their own user account once
the newly installed machine is started for the first time.

Still, while Initial Setup normally does not have many options
available, if the firstboot --reconfig kickstart command is provided
in the installation kickstart, Initial Setup will show all configuration
options available. This is usually used for OEM OS installations,
where an OEM installs the computer, which is then shipped to the end user
which uses Initial Setup for the final configuration of the operating system.

Architecture
============
Initial Setup is basically just a thin wrapper for running spokes from Anaconda.
Still, it has its own Hub, one spoke (the EULA spoke) and a translation domain ("initial-setup").

As with Anaconda, Initial Setup has both a GUI and TUI version and the package is split
into a core and GUI & TUI sub packages.

As Initial Setup needs to run during the early boot, it is started by a systemd unit
configured to start before the normal login screen.

On RHEL7 Initial Setup is by default followed by the legacy Firstboot utility,
which at the moment does not have any plugins by default and should thus terminate
immediately. If the given OS instance uses the Gnome 3 desktop environment,
Firstboot is followed by the Gnome Initial Setup(GIS), which enables the user to customize
their computer even more.

On RHEL8 Firstboot is no longer available and thus Initial Setup is followed by Gnome Initial Setup
on RHEL Workstation installs and directly with the login screen elsewhere.

On Fedora Initial Setup is followed directly by GIS, provided Gnome 3 is installed.

* RHEL8: IS -> [GIS]
* RHEL7: IS -> Firstboot -> [GIS]
* Fedora: IS -> [GIS]

Addons
======
Like Anaconda, also Initial Setup can be used to host third party addons - flexible
yet powerful modules that can configure the system based on data in kickstart
while presenting a nice UI to the user. Addons can have a GUI, TUI or can be
headless, working only with data in their kickstart section or from other sources.

For comprehensive documentation about Anaconda/Intial Setup see the
"Anaconda Addon Development Guide" by Vratislav Podzimek:

* https://rhinstaller.github.io/anaconda-addon-development-guide/

Testing
=======
To start tests please first install package ``tmt-all`` to your system and call::

    make test

First time you call the above it will setup all dependencies and then execute the tests.
If you need to do the initialization of the tests again, please run::

    make test-cleanup

In case you want to use custom Anaconda code, please provide a COPR repository with the Anaconda
(can be easily created by ``packit copr-build`` in the Anaconda branch) and execute::

    make test TMT_COPR_ANACONDA_REPO=<owner/anaconda>

Please note, you need to call ``make test-cleanup`` first to re-initialize test environment with
your custom Anaconda code.

Contributing
============
* Initial Setup is released under GPLv2+
* upstream source code repository is on GitHub: https://github.com/rhinstaller/initial-setup
